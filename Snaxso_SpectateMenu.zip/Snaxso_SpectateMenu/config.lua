Config = {} -- 

Config.AllowedGroups = {
	["admin"] = true,
}

Config.SpectateMenuCommand = "spectatemenu" --Komanda su kuria galite stebėti žmogų

Config.StopSpecKey = 38 


Config.KickMessage = "Jus esate išmestas iš serverio"
Config.KickPlayerMessage = "Žaidėjas yra išmestas"
Config.KickSelfMessage = "Jus negalite išmesti savęs"
Config.SelfSpectateMessage = "Jus negalite stebėti savęs"