# Snaxso_SpectateMenu

Sveiki atvykę į Snaxso_SpectateMenu saugyklą! Šis skriptas pateikia supaprastintą ir minimalistinį administratoriaus stebėjimo meniu, skirtą efektyviai valdyti žaidėjus jūsų FiveM serveryje.

## Funkcijos

1. **Žaidėjų paieška:** Administratoriai gali greitai ieškoti prieinamų žaidėjų serveryje.

2. **Stebėjimas ir išmetimas:** Administratoriai gali stebėti žaidėjus ir, jei reikia, juos pašalinti.

3. **Žaidėjų sąrašo rūšiavimas:** Galima rūšiuoti žaidėjų sąrašą pagal ID, vardą, darbus ir grupę.

4. **Minimalistinė sąsaja:** Naudotojo sąsaja sukurta taip, kad būtų paprasta ir be nereikalingų trukdžių.

5. **Leidžiamos grupės:** Nustatykite, kurios grupės gali naudotis administravimo funkcijomis, konfigūracijos faile.

6. **Konfigūruojamas:** Lengvai pritaikomas konfigūracinis failas leidžia adaptuoti skriptą pagal jūsų serverio poreikius.

## Įdiegimas

1. Pridėkite skriptą į `server.cfg` failą:

    ```cfg
    ensure Snaxso_SpectateMenu
    ```

2. Redaguokite `config.lua` failą pagal savo poreikius.

## Naudojimas

- Atidarykite stebėjimo meniu naudodami komandą (pvz., `/spectatemenu`).

- Naudokite paieškos laukelį žaidėjams rasti.

- Naudokite antraštes žaidėjų sąrašui rūšiuoti.

- Pasirinkite žaidėją, kurį norite stebėti ar pašalinti iš serverio.

- Tvarkykite leidžiamas grupes faile `config.lua`.

## Konfigūracija

Redaguokite `config.lua` failą pagal savo poreikius. Pavyzdys:

```lua
Config.AllowedGroups = {
	["admin"] = true,
	-- ["mod"] = false, -- Galite pridėti kitas grupes tokiu būdu
}
